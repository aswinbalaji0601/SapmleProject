# Microservice and component based Ecommerce / Web Shop application
A full stack micorservice and component based ecommerce  online shopping (eShop) application written using Java, Spring and Spring Boot  in Backend, Angular, Material UI and Tailwind CSS in frontend.

Some snapshots of how it looks:

<img width="959" alt="image" src="https://github.com/SatyaRajAwasth1/ecommerce-fullstack/assets/77236280/a42f9cef-f47e-4074-a48e-22e6c845969f">
<br/><br/>
<img width="960" alt="image" src="https://github.com/SatyaRajAwasth1/ecommerce-fullstack/assets/77236280/89328af8-c5bf-4b4a-a09c-cad256125d68">
<br/><br/>
<img width="960" alt="image" src="https://github.com/SatyaRajAwasth1/ecommerce-fullstack/assets/77236280/6c042d1a-b347-4d72-87e5-cc49ffbf1e69">
<br/><br/>
<img width="960" alt="image" src="https://github.com/SatyaRajAwasth1/ecommerce-fullstack/assets/77236280/ccdee517-3b04-420b-a3d6-6e4c36448e4e">
<br/><br/>
<img width="960" alt="image" src="https://github.com/SatyaRajAwasth1/ecommerce-fullstack/assets/77236280/bcc86c70-e149-4a37-b8a3-17f7d775cc42">
<br/><br/>
<img width="960" alt="image" src="https://github.com/SatyaRajAwasth1/ecommerce-fullstack/assets/77236280/6d916f10-4a3a-4cfb-8b00-161b9152c18e">
<br/><br/>
<img width="960" alt="image" src="https://github.com/SatyaRajAwasth1/ecommerce-fullstack/assets/77236280/700db98c-3913-4003-aaea-406586624002">
<br/><br/>
<img width="960" alt="image" src="https://github.com/SatyaRajAwasth1/ecommerce-fullstack/assets/77236280/1e18e71d-e6e0-41bc-b0fc-8884af6e5285">
<br/><br/>
<img width="960" alt="image" src="https://github.com/SatyaRajAwasth1/ecommerce-fullstack/assets/77236280/2f8dc46b-a7b8-4ce4-81f1-bb085b0e76c1">

