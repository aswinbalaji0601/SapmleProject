export interface Product{
    productId: number;
    productName: string;
    price: number;
    category: string;
    description: string;
    image: string;
}